document.addEventListener('DOMContentLoaded', () => {
  const contactForm = document.getElementById('contactForm');
  const alertPlaceholder = document.getElementById('alertPlaceholder');

  const appendAlert = (message, type) => {
    const wrapper = document.createElement('div');
    wrapper.innerHTML = [
      `<div class="alert alert-${type} alert-dismissible" role="alert">`,
      `   <div>${message}</div>`,
      '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
      '</div>'
    ].join('');

    alertPlaceholder.append(wrapper);
  }

  if (contactForm) {
    contactForm.addEventListener('submit', (event) => {
        event.preventDefault(); // Prevent actual form submission
        
        // In a real app, you would handle data sending here.
        // For this task, we just show the alert.
        appendAlert('Message sent!', 'success');
        
        // Optional: Clear the form
        contactForm.reset();
    });
  }
});
